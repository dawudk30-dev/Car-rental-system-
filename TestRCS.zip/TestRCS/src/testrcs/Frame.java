package testrcs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Admin
 */
public  class Frame extends JFrame implements MouseListener
{
    
    public JLabel lbName=new JLabel();
    public   JLabel lbin=new JLabel();
    public JTextField txtName=new JTextField();
    public  JTextField txtN=new JTextField();
    public JTextField m0=new JTextField();
    public JTextField m1=new JTextField();
    public JTextField m2=new JTextField();
    public   JLabel ibnm0=new JLabel();
    public   JLabel ibnm1=new JLabel();
    public   JLabel ibnm2=new JLabel();
    public JTextField m3=new JTextField();
    public JTextField m4=new JTextField();
    public   JLabel ibnm3=new JLabel();
    public   JLabel ibnm4=new JLabel();
    public JLabel lbFName=new JLabel();
    public JLabel lbN=new JLabel();
    public JLabel lbi=new JLabel();
    public JTextField txti=new JTextField();
    public JTextField txtFName=new JTextField();
    public JLabel lbAge=new JLabel();
    public JTextField txtAge=new JTextField();
    public JLabel lbGender=new JLabel();
    public  JRadioButton rdMale=new JRadioButton();
    public   JRadioButton rdFemale=new JRadioButton();
    public Font f=new Font("Times New Roman",Font.PLAIN,24);
    public Font f1=new Font("Arial",Font.PLAIN,18);
    public ButtonGroup grp=new ButtonGroup();
    public JButton btnAdd=new JButton();
    public JButton btnRead=new JButton();
    public JButton btnDelete=new JButton();
    public JButton btnA1=new JButton();
    public JButton btnR1=new JButton();
    public JButton btnD1=new JButton();
    public JButton h=new JButton();
    public JButton r=new JButton();
    public JLabel cl=new JLabel();
    
    String[][] data={
        {"Azrar","Ahmed","40","Male","0315324415","1350367738693","15000","Toyoto xli","3"}
                    };
    
    String [] cols={"Name", "F Name","Age","Gender","Contact Number"," IDC Number ","Rent","CaR","Days"};
    
    
    String[][] datar={
        {"Sadiq uzair","Honda city","7000"}
                     };
    
    String [] colsr={"Driver Name", "Car Name","Price per Day"};
    
   public DefaultTableModel tm=new DefaultTableModel(datar,colsr);
   public JTable tb1=new JTable(tm);
    
    
    
    
   public DefaultTableModel tmod=new DefaultTableModel(data,cols);
   public JTable tb=new JTable(tmod);
    
    public void intialize()
    {
 
        tb1.addMouseListener(this);
        JScrollPane sc1=new JScrollPane(tb1);
        sc1.setBounds(620,400,400,300);
        this.add(sc1);
        File fr1=new File("rent.txt");
        try
        {
        Scanner input=new Scanner(fr1);
        while(input.hasNext())
        {
            String str1=input.nextLine();
            String[] row1=str1.split(",");
            tm.addRow(row1);
        }
        input.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
   
        
        tb.addMouseListener(this);
        JScrollPane sc=new JScrollPane(tb);
        sc.setBounds(10,400,600,300);
        this.add(sc);
        
        File fr=new File("Client.txt");
        try
        {
        Scanner input=new Scanner(fr);
        while(input.hasNext())
        {
            String str=input.nextLine();
            String[] row=str.split(",");
            tmod.addRow(row);
        }
        input.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        
        ibnm0.setText("1.Add your days");
        ibnm0.setFont(f1);
        ibnm0.setBounds(1020,400,180,30);
        this.add(ibnm0);
        
        ibnm1.setText("2.Select your car price");
        ibnm1.setFont(f1);
        ibnm1.setBounds(1020,460,210,30);
        this.add(ibnm1);
        
        ibnm2.setText("Final Rent");
        ibnm2.setFont(f1);
        ibnm2.setBounds(1020,520,120,30);
        this.add(ibnm2);
        
        ibnm3.setText("Driver Name");
        ibnm3.setFont(f1);
        ibnm3.setBounds(1020,580,210,30);
        this.add(ibnm3);
        
        ibnm4.setText("Car Name");
        ibnm4.setFont(f1);
        ibnm4.setBounds(1020,640,120,30);
        this.add(ibnm4);
        
        m0.setText("");
        m0.setFont(f1);
        m0.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        m0.setBounds(1250,400,120,30);
        this.add(m0);
        
        m1.setText("");
        m1.setFont(f1);
        m1.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        m1.setBounds(1250,460,120,30);
        this.add(m1);
        
        m2.setText("");
        m2.setFont(f1);
        m2.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        m2.setBounds(1250,520,120,30);
        this.add(m2);
        
        
        m3.setText("");
        m3.setFont(f1);
        m3.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        m3.setBounds(1250,580,120,30);
        this.add(m3);
        
        m4.setText("");
        m4.setFont(f1);
        m4.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        m4.setBounds(1250,640,120,30);
        this.add(m4);
        
        
        
        lbName.setText("3.Name");
        lbName.setBounds(20,220,100,30);
        lbName.setFont(f1);
        this.add(lbName);
        txtName.setBounds(160,220,200,30);
        txtName.setFont(f1);
        txtName.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(txtName);
        
        
        lbFName.setText("4.F Name");
        lbFName.setBounds(20,270,100,30);
        lbFName.setFont(f1);
        this.add(lbFName);
        
        lbin.setText("Enter all the information of Client including its personal Details(must be Confidential)");
        lbin.setBounds(210,100,900,30);
        lbin.setFont(f);
        this.add(lbin);
        
        txtFName.setBounds(160,270,200,30);
        txtFName.setFont(f1);
        txtFName.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(txtFName);
        
        lbAge.setText("5.Age");
        lbAge.setBounds(20,320,100,30);
        lbAge.setFont(f1);
        this.add(lbAge);
        
        txtAge.setBounds(160,320,200,30);
        txtAge.setFont(f1);
        txtAge.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(txtAge);
        
        txtN.setBounds(750,270,200,30);
        txtN.setFont(f1);
        txtN.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(txtN);
        
        txti.setBounds(750,320,200,30);
        txti.setFont(f1);
        txti.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(txti);
        
        lbGender.setText("6.Gender");
        lbGender.setBounds(620,220,100,30);
        lbGender.setFont(f1);
        this.add(lbGender);
        
        lbN.setText("7.Cell Number");
        lbN.setBounds(620,270,150,30);
        lbN.setFont(f1);
        this.add(lbN);
        
        Icon cli=new ImageIcon(this.getClass().getResource("client (1).png"));
        cl.setIcon(cli);
        cl.setText("");
        cl.setBounds(10,20,200,200);
        this.add(cl);
        
        lbi.setText("8.I-D Number");
        lbi.setBounds(620,320,150,30);
        lbi.setFont(f1);
        this.add(lbi);
        
        rdMale.setText("Male");
        rdMale.setBounds(750,220,100,30);
        rdMale.setFont(f1);
        rdMale.setBackground(Color.GRAY);
        this.add(rdMale);
        
        rdFemale.setText("Female");
        rdFemale.setBounds(850,220,100,30);
        rdFemale.setFont(f1);
        rdFemale.setBackground(Color.GRAY);
        this.add(rdFemale);
        grp.add(rdMale);
        grp.add(rdFemale);
        
        Icon a=new ImageIcon(this.getClass().getResource("add3.png"));
        btnAdd.setText("ADD");
        btnAdd.setFont(f);
        btnAdd.setIcon(a);
        btnAdd.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        btnAdd.setBounds(1050,10,155,151);
        btnAdd.setBackground(Color.GRAY);
        btnAdd.setHorizontalAlignment(SwingConstants.LEFT);
        btnAdd.addActionListener(new btn_Click());
        this.add(btnAdd);
        
        btnA1.setText("Add data");
        btnA1.setFont(f1);
        btnA1.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        btnA1.setBounds(620,366,130,30);
        btnA1.setBackground(Color.GRAY);
        btnA1.setHorizontalAlignment(SwingConstants.CENTER);
        btnA1.addActionListener(new btn_Click());
        this.add(btnA1);
        
        
        Icon home=new ImageIcon(this.getClass().getResource("home2.png"));
        h.setText("home");
        h.setFont(f1);
        h.setIcon(home);
        h.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        h.setBounds(1260,30,105,100);
        h.setBackground(Color.GRAY);
        h.setHorizontalAlignment(SwingConstants.LEFT);
        h.addActionListener(new btn_Click());
        this.add(h);
         
        Icon up=new ImageIcon(this.getClass().getResource("update.png"));
        btnRead.setText("Update");
        btnRead.setFont(f);
        btnRead.setIcon(up);
        btnRead.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        btnRead.setBounds(1050,170,153,153);
        btnRead.setBackground(Color.GRAY);
        btnRead.setHorizontalAlignment(SwingConstants.LEFT);
        btnRead.addActionListener(new btn_Click());
        this.add(btnRead);
        
        
        Icon del=new ImageIcon(this.getClass().getResource("delete.png"));
        btnDelete.setText("DELETE");
        btnDelete.setFont(f);
        btnDelete.setIcon(del);
        btnDelete.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        btnDelete.setBounds(1230,170,155,153);
        btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
        btnDelete.setBackground(Color.GRAY);
        btnDelete.addActionListener(new btn_Click());
        this.add(btnDelete);
        
        btnD1.setText("Delete Data");
        btnD1.setFont(f1);
        btnD1.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        btnD1.setBounds(890,366,130,30);
        btnD1.setHorizontalAlignment(SwingConstants.CENTER);
        btnD1.setBackground(Color.GRAY);
        btnD1.addActionListener(new btn_Click());
        this.add(btnD1);
        
        btnR1.setText("Reset");
        btnR1.setFont(f1);
        btnR1.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        btnR1.setBounds(758,366,130,30);
        btnR1.setHorizontalAlignment(SwingConstants.CENTER);
        btnR1.setBackground(Color.GRAY);
        btnR1.addActionListener(new btn_Click());
        this.add(btnR1);
        
    }   

    @Override
    public void mouseClicked(MouseEvent me) 
    {
    int index1=tb1.getSelectedRow();
    m3.setText(tm.getValueAt(index1, 0).toString());  
    m4.setText(tm.getValueAt(index1, 1).toString()); 
    m1.setText(tm.getValueAt(index1, 2).toString());
    
    int index=tb.getSelectedRow();
    txtName.setText(tmod.getValueAt(index, 0).toString());
    txtFName.setText(tmod.getValueAt(index, 1).toString());
    txtAge.setText(tmod.getValueAt(index, 2).toString());
    String gen=tmod.getValueAt(index, 3).toString();
    if(gen.compareTo("Male")==0)
    {
        rdMale.setSelected(true);
    }
    else
    {
        rdFemale.setSelected(true);
    }
    txtN.setText(tmod.getValueAt(index, 4).toString());
    txti.setText(tmod.getValueAt(index, 5).toString());
    }

    @Override
    public void mousePressed(MouseEvent me) {
   //     throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent me) {
     //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent me) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent me) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public class btn_Click implements ActionListener
    {
        public static int val;
        public static int v;
        @Override
        public void actionPerformed(ActionEvent ae) 
        {
            String op=ae.getActionCommand();
            if(op.compareTo("ADD")==0)
            {
                val=Integer.parseInt(m0.getText());
                v=Integer.parseInt(m1.getText());
                int res=(val*v);
                m2.setText(Integer.toString(res));
                
               String gen=rdFemale.isSelected()?"Female":"Male";
               String [] row={txtName.getText(),txtFName.getText(),txtAge.getText(),gen,txtN.getText(),txti.getText(),m2.getText(),m4.getText(),m0.getText()};
               tmod.addRow(row);
               try
               {
                   
               File f=new File("Client.txt");
               FileWriter fr=new FileWriter(f,true);
               fr.write(txtName.getText()+","+txtFName.getText()+","+txtAge.getText()+","+gen+","+txtN.getText()+","+txti.getText()+","+m2.getText()+","+m4.getText()+","+m0.getText()+"\n");
               JOptionPane.showMessageDialog(btnAdd, "Record Added","Information", JOptionPane.INFORMATION_MESSAGE);
               fr.close();
               }
               catch(Exception ex)
               {
                   
               }
            }
            else
            if(op.compareTo("DELETE")==0)
            {
                if(tb.getSelectedRow()==-1)
                {
           JOptionPane.showMessageDialog(btnDelete, "Please select the line first","Information", JOptionPane.INFORMATION_MESSAGE);

                }
                else
                {
                 tmod.removeRow(tb.getSelectedRow());
                       try
                {
                String str=txtName.getText();
                File f=new File("Client.txt");
                File ftemp=new File("temp.txt");
                FileWriter frtemp=new FileWriter(ftemp);
                Scanner input=new Scanner(f);
                int flg=1;
                while(input.hasNext())
                {
                    String ln=input.nextLine();
                    String[] arr=ln.split(",");
                    if(str.compareTo(arr[0])==0)
                    {
                        flg=0;
                    }
                    else
                    {
                        frtemp.write(ln+"\n");
                    }
                }
                frtemp.close();
                input.close();
                if(flg==0)
                {
                    System.out.println("Record Deleted");
                }
                else
                {
                    System.out.println("Record Not Found");
                }
                f.delete();
                ftemp.renameTo(new File("Client.txt"));
                //System.out.println("Record Deleted");
                }
                catch(Exception ex)
                {
                    System.out.println(ex.getMessage());
                }
            
                 
                }
            }
            
            else
            if(op.compareTo("Update")==0)
            {
                int index=tb.getSelectedRow();
                if(index==-1)
                {
JOptionPane.showMessageDialog(btnRead, "Please select the line first","Information", JOptionPane.INFORMATION_MESSAGE);

                }
                else
                {
                tmod.setValueAt(txtName.getText(), index, 0);
                tmod.setValueAt(txtFName.getText(), index, 1);
                tmod.setValueAt(txtAge.getText(), index, 2);
                String gen=rdFemale.isSelected()?"Female":"Male";
                tmod.setValueAt(gen, index, 3);
                tmod.setValueAt(txtN.getText(), index, 4);
                tmod.setValueAt(txti.getText(), index, 5);
                tmod.setValueAt(m2.getText(), index, 6);
                tmod.setValueAt(m4.getText(), index, 7);
                tmod.setValueAt(m0.getText(), index, 8);
              
                   
               
         
                
    
                
           //    tmod.setValueAt(op, WIDTH, WIDTH);
            }
                
        }
            else if(op.compareTo("home")==0)
            {
        Design n=new Design();
        n.setTitle("RCS");
        n.setSize(400,300);
        n.getContentPane().setBackground(Color.ORANGE);
        n.setVisible(true);
        n.intialize();
        n.setExtendedState(JFrame.MAXIMIZED_BOTH);
        n.setLayout(null);
        n.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }
            else if(op.compareTo("Add data")==0)
            {
                 
               String [] row1={m3.getText(),m4.getText(),m1.getText()};
               tm.addRow(row1);
               try
               {
                   
               File f1=new File("rent.txt");
               FileWriter fr1=new FileWriter(f1,true);
               fr1.write(m3.getText()+","+m4.getText()+","+m1.getText()+"\n");
               JOptionPane.showMessageDialog(btnA1, "Record Added","Information", JOptionPane.INFORMATION_MESSAGE);
               fr1.close();
               }
               catch(Exception ex)
               {
                   
               }
                
            }
            else if(op.compareTo("Delete Data")==0)
            {
                if(tb1.getSelectedRow()==-1)
                {
           JOptionPane.showMessageDialog(btnD1, "Please select the line first","Information", JOptionPane.INFORMATION_MESSAGE);

                }
                else
                {
                 tm.removeRow(tb1.getSelectedRow());
                       try
                {
                String str=m3.getText();
                File f=new File("rent.txt");
                File ftemp=new File("temp.txt");
                FileWriter frtemp=new FileWriter(ftemp);
                Scanner input=new Scanner(f);
                int flg=1;
                while(input.hasNext())
                {
                    String ln=input.nextLine();
                    String[] arr=ln.split(",");
                    if(str.compareTo(arr[0])==0)
                    {
                        flg=0;
                    }
                    else
                    {
                        frtemp.write(ln+"\n");
                    }
                }
                frtemp.close();
                input.close();
                f.delete();
                ftemp.renameTo(new File("rent.txt"));
                }
                catch(Exception ex)
                {
                    System.out.println(ex.getMessage());
                }
            
                 
                }
            }
            
            else if(op.compareTo("Reset")==0)
            {
                txtName.setText("");
                txtFName.setText("");
                txtN.setText("");
                m3.setText("");
                m4.setText("");
                m1.setText("");
                m0.setText("");
                m2.setText("");
                txti.setText("");
                txtAge.setText("");
                
                
                
            }
            
            
            

        
    }
    }
}
    
