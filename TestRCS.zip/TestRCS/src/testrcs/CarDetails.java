/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testrcs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 *
 * @author universal
 */
public class CarDetails extends JFrame implements ActionListener
        
{
    public JButton e=new JButton();
    public JLabel head=new JLabel();
    public JLabel m=new JLabel();
     public JLabel m1=new JLabel();
     
     public JLabel xli=new JLabel();
      public JLabel xli1=new JLabel();
      
       public JLabel p=new JLabel();
        public JLabel p1=new JLabel();
        
         public JLabel v=new JLabel();
          public JLabel v1=new JLabel();
          
           public JLabel h=new JLabel();
            public JLabel h1=new JLabel();
            
             public JLabel hi=new JLabel();
              public JLabel hi1=new JLabel();
              
                public Font f=new Font("Arial",Font.PLAIN,20);
    public void intialize()
    {
         Icon m0=new ImageIcon(this.getClass().getResource("jm.png"));
         m.setIcon(m0);
        m.setText("");
        m.setBounds(300,80,250,250);
        this.add(m);
        
        m1.setText("1.Mehran Alto");
        m1.setFont(f);
        m1.setBounds(300, 320, 200, 30);
        this.add(m1);
        
        head.setText("Rental Car Service");
        head.setBounds(550, 20, 290, 40);
        head.setBackground(Color.lightGray);
        head.setOpaque(true);
        head.setHorizontalAlignment(SwingConstants.CENTER);
        head.setForeground(Color.red);
        head.setFont(f);
        this.add(head);
        
         Icon x=new ImageIcon(this.getClass().getResource("jc.png"));
         xli.setIcon(x);
        xli.setText("");
        xli.setBounds(600,80,300,250);
        this.add(xli);
        
        xli1.setText("2.Corolla xli");
        xli1.setFont(f);
        xli1.setBounds(600, 320, 200, 30);
        this.add(xli1);
        
           Icon p0=new ImageIcon(this.getClass().getResource("jp (1).png"));
         p.setIcon(p0);
        p.setText("");
        p.setBounds(300,360,250,250);
        this.add(p);
        
         p1.setText("6.Toyoto Hi-Ace");
        p1.setFont(f);
        p1.setBounds(300, 600, 200, 30);
        this.add(p1);
        
         Icon v0=new ImageIcon(this.getClass().getResource("jv (1).png"));
         v.setIcon(v0);
        v.setText("");
        v.setBounds(600,360,250,250);
        this.add(v);
        
        v1.setText("6.Toyoto Hi-Ace");
        v1.setFont(f);
        v1.setBounds(600, 600, 200, 30);
        this.add(v1);
        
          Icon h0=new ImageIcon(this.getClass().getResource("jh.png"));
         h.setIcon(h0);
        h.setText("");
        h.setBounds(900,80,250,250);
        this.add(h);
        
        h1.setText("3.Honda City");
        h1.setFont(f);
        h1.setBounds(900, 320, 200, 30);
        this.add(h1);
        
         Icon hi0=new ImageIcon(this.getClass().getResource("jhi.png"));
         hi.setIcon(hi0);
        hi.setText("");
        hi.setBounds(900,360,250,250);
        this.add(hi);
        
         hi1.setText("6.Toyoto Hi-Ace");
        hi1.setFont(f);
        hi1.setBounds(900, 600, 200, 30);
        this.add(hi1);
        
        e.setText("Back");
        e.setBounds(1250,570,90,40);
        //btncd.setIcon(ic1);
       e.setHorizontalAlignment(SwingConstants.LEFT);
        e.setBorder(BorderFactory.createLineBorder(Color.orange,4));
        e.setFont(f);
        e.addActionListener(this);
        this.add(e);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String op=e.getActionCommand();
        if(op.compareTo("Back")==0)
        {
            
        
        Design f=new Design();
        f.setTitle("RCS");
        f.setSize(400,300);
        f.getContentPane().setBackground(Color.yellow);
        f.setVisible(true);
        f.intialize();
        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
