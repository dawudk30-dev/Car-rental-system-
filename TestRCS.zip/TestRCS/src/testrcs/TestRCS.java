    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testrcs;
import javax.swing.JFrame;
import java.awt.Color;
/**
 *
 * @author universal
 */
public class TestRCS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Design f=new Design();
        f.setTitle("RCS");
        f.setSize(400,300);
        f.getContentPane().setBackground(Color.yellow);
        f.setVisible(true);
        f.intialize();
        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
}
}