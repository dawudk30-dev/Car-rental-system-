/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testrcs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.BorderFactory;
import javax.swing.SwingConstants;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

/**
 *
 * @author Admin
 */
public class Design extends JFrame implements ActionListener,WindowListener
{
    public static int flg=0;
    public  JLabel h=new JLabel();
    public  JLabel H=new JLabel();
    
    public  JLabel hh=new JLabel();
    public  JLabel HH=new JLabel();
    public  JLabel Hi=new JLabel();
    JButton btnc=new JButton();
    JButton btncd=new JButton();
    
    JButton e=new JButton();
    
    Font f2=new Font("Arial",Font.BOLD+Font.ITALIC,20);
    Font f=new Font("Arial",Font.BOLD,16);
    Font f1=new Font("Arial",Font.BOLD,30);
    public void intialize()
    {
        Icon ic=new ImageIcon(this.getClass().getResource("client.png"));
        btnc.setText("Clients Info.");
        btnc.setBounds(1010,230,210,200);
        btnc.setIcon(ic);
        
        btnc.setHorizontalAlignment(SwingConstants.CENTER);
        btnc.setBorder(BorderFactory.createLineBorder(Color.yellow,4));
        btnc.setFont(f);
        btnc.addActionListener(this);
        this.add(btnc);
        
        
        Icon ic1=new ImageIcon(this.getClass().getResource("car1.png"));
        btncd.setText("Rent your Car");
        btncd.setBounds(1010,480,210,200);
        btncd.setIcon(ic1);
        btncd.setHorizontalAlignment(SwingConstants.LEFT);
        btncd.setBorder(BorderFactory.createLineBorder(Color.yellow,4));
        btncd.setFont(f);
        btncd.addActionListener(this);
        this.add(btncd);
        
        //Icon ic1=new ImageIcon(this.getClass().getResource("car1.png"));
        e.setText("Exit");
        e.setBounds(1250,570,90,40);
        //btncd.setIcon(ic1);
       e.setHorizontalAlignment(SwingConstants.LEFT);
        e.setBorder(BorderFactory.createLineBorder(Color.orange,4));
        e.setFont(f2);
        e.addActionListener(this);
        this.add(e);
                
        h.setText("It is my pleasure to welcome you for using our app I'd like to thank you for joining us today for our Car services.");
        h.setBounds(10, 100, 1100, 30);
        h.setForeground(Color.DARK_GRAY);
        h.setFont(f2);
        this.add(h);    
        
        H.setText("Rental Car Service");
        H.setBounds(550, 20, 290, 40);
        H.setBackground(Color.lightGray);
        H.setOpaque(true);
        H.setForeground(Color.red);
        H.setFont(f1);
        this.add(H);
        
         hh.setText("Client info.");
       hh.setBounds(1240, 230, 100, 30);
       hh.setForeground(Color.black);
        hh.setFont(f);
        this.add(hh);
        
         HH.setText("Car Details");
        HH.setBounds(1240, 480, 100, 30);
       HH.setForeground(Color.black);
        HH.setFont(f);
        this.add(HH);
        
    
       Icon ic2=new ImageIcon(this.getClass().getResource("home1.png"));
        Hi.setBounds(6, 2, 900, 900);
        Hi.setIcon(ic2);
        Hi.setBackground(Color.orange);
       Hi.setOpaque(true);
        Hi.setForeground(Color.red);
        Hi.setFont(f1);
        this.add(Hi);
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) 
    {
        String op=ae.getActionCommand();
        if(op.compareTo("Clients Info.")==0)
        {
       if(flg==0)
       {
        login f=new login();
        f.pre();
        f.getContentPane().setBackground(Color.yellow);
        f.setSize(400,300);
        f.setResizable(false);
        f.setLayout(null);
        f.setVisible(true);
        f.addWindowListener(this);
        flg=1;
       }
        }
        else
        if(op.compareTo("Rent your Car")==0&&flg==1)
        {
        CarDetails f=new CarDetails();
        f.setTitle("Car Info.");
        f.intialize();
        f.getContentPane().setBackground(Color.LIGHT_GRAY);
        f.setSize(500,600);
        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setLayout(null);
        f.setVisible(true);
        flg=0;
        
        }
        else if(op.compareTo("Exit")==0){
             System.exit(0);
        }
        
    }

    @Override
    public void windowOpened(WindowEvent we) 
    {
        
     }

    @Override
    public void windowClosing(WindowEvent we) {
    flg=0; 
    }

    @Override
    public void windowClosed(WindowEvent we) {
        flg=0;
     }

    @Override
    public void windowIconified(WindowEvent we) {
    }

    @Override
    public void windowDeiconified(WindowEvent we) {
        }

    @Override
    public void windowActivated(WindowEvent we) {
         }

    @Override
    public void windowDeactivated(WindowEvent we) {
          }
    
}