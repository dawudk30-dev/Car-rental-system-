/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testrcs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.border.Border;

/**
 *
 * @author universal
 */
public class login extends JFrame implements ActionListener 
{
    Frame f0=new Frame();
    public JLabel login=new JLabel();
    public JLabel p1=new JLabel();
    public JLabel name=new JLabel();
    public JTextField n=new JTextField();
    public JLabel pass=new JLabel();
    public JPasswordField p=new JPasswordField();
    public JButton s=new JButton();
    public JButton r=new JButton();
    Design d=new Design();
    Font f=new Font("Times New Roman",Font.BOLD,26);
    Font f1=new Font("Arial",Font.PLAIN,20);
    Font f2=new Font("Arial",Font.PLAIN,14);
    public void pre()
    {
        login.setText("Please login");
        login.setBounds(100, 30, 150, 30);
        login.setHorizontalAlignment(JLabel.RIGHT);
        login.setFont(f);
        this.add(login);
        
        p1.setText("");
        p1.setBounds(45, 50, 300, 30);
        p1.setHorizontalAlignment(JLabel.CENTER);
        p1.setForeground(Color.red);
        p1.setFont(f2);
        this.add(p1);
        
        
        name.setText("Name");
        name.setBounds(10, 100, 80, 30);
        name.setFont(f1);
        this.add(name);
        
        n.setBounds(10, 130, 140, 30);
        n.setBackground(Color.white);
        n.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(n);
        
        pass.setText("Password");
        pass.setBounds(200, 100, 100, 30);
        pass.setFont(f1);
        this.add(pass);
        
        p.setBounds(200, 130, 140, 30);
        p.setBackground(Color.white);
        p.setBorder(BorderFactory.createLineBorder(Color.orange,3));
        this.add(p);
        
        
        s.setText("Submit");
        s.setBounds(10, 200,100, 30);
        s.setFont(f1);
        s.addActionListener(this);
        this.add(s);
        
        
        r.setText("Reset");
        r.setBounds(200, 200,100, 30);
        r.setFont(f1);
        r.addActionListener(this);
        this.add(r);
        
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
       if(e.getSource()==s)
       {
       if("Dawud".equals(n.getText()) && "Khan".equals(p.getText())){
        f0.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f0.setTitle("Clients Info.");
        f0.intialize();
        f0.getContentPane().setBackground(Color.yellow);
        f0.setLayout(null);
        f0.setVisible(true);
        f0.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        else{
            p1.setText("Wrong Name Or Password try Again.");
        }
        }
    else if(e.getSource()==r)
        {
            n.setText("");
            p.setText("");
            p1.setText("");
        }
    
}
}

